# Business Central performance layer

This update preserves the existing service and hook signatures. Existing Business Central endpoint paths are unchanged; the internal transport now routes them through `/api/bc` so caching, deduplication and throttling are centralized.

## Install

The uploaded source did not contain the project's `package.json`, so add these dependencies to the existing project:

```bash
npm install lru-cache p-queue ioredis
```

TanStack Query is already used by this application.

## Environment

```env
BC_MAX_CONCURRENCY=3
BC_RAM_CACHE_MAX=500
# Optional shared cache / durable job store:
REDIS_URL=redis://:password@host:6379
```

Keep `BC_CLIENT_SECRET` server-side. Do not expose it through `NEXT_PUBLIC_*` variables.

## GET optimization

- Browser request concurrency is limited to 3.
- Server Business Central concurrency is independently limited to `BC_MAX_CONCURRENCY` (default 3).
- Identical in-flight GETs are deduplicated in the browser and server.
- L1: `lru-cache` RAM cache.
- L2: `ioredis` when `REDIS_URL` is configured.
- Suggested TTLs are path-aware: customers 10m, items 10m, locations 30m, payment terms 30m, pricing/discounts 90s, inventory 30s.
- GETs send `Data-Access-Intent: ReadOnly`.
- 408/429/502/503/504 use exponential backoff with jitter.
- Writes are never cached; successful writes invalidate the GET cache.

## Durable Sales Order jobs

The existing `createSalesOrder(payload)` function remains synchronous so the current UI workflow is not silently changed.

An additive durable job API is included:

- `POST /api/jobs/sales-order` -> `{ success: true, status: "PENDING", jobId }`
- `GET /api/jobs/sales-order/status?jobId=...`
- `POST /api/jobs/worker` processes one persisted job.

Jobs, idempotency keys, header progress and completed line numbers are persisted in Redis. This means a browser/tab closing does not delete an accepted job. A worker/scheduler should call `/api/jobs/worker` periodically; do not expose this route publicly without authentication. `REDIS_URL` is required for this durable mode.

The worker records the Business Central header ID and completed line numbers before continuing, so worker retries do not blindly recreate already-completed parts of an order.
