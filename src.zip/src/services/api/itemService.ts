import {
  BC_TENANT_ID,
  BC_COMPANY_ID,
  BC_API_BASE_URL,
  BC_ENV_NAME,
} from "@/constants";

import { BCItem } from "@/types";
import { getOAuthToken } from "../auth/tokenService";
import { useAuthStore } from "@/store/authStore";
const user = useAuthStore.getState().user;

// ======================================================
// BC HELPER
// ======================================================

import { bcFetch } from "./bcRequest";

async function bcGet<T>(
  path: string,
  params: Record<string, string> = {},
): Promise<T> {
  const searchParams = new URLSearchParams(params);

  const tokenData = await getOAuthToken();
  console.log(user?.ItemCat);
  const url =
    `${BC_API_BASE_URL}/${BC_TENANT_ID}/${BC_ENV_NAME}` +
    `/api/v2.0/companies(${BC_COMPANY_ID})${path}` +
    `?${searchParams.toString()}`;

  const res = await bcFetch(url, {
    headers: {
      Authorization: `Bearer ${tokenData.access_token}`,
      Accept: "application/json",
      Prefer: "odata.include-annotations=*",
    },
    cache: "no-store",
  });

  if (!res.ok) {
    const errorText = await res.text();

    throw new Error(`Business Central API Error ${res.status}: ${errorText}`);
  }

  return res.json();
}

// ======================================================
// GET ITEMS
// ======================================================

export async function getItems(search?: string): Promise<BCItem[]> {
  try {
    const categories = (user?.ItemCat ?? "")
      .split("|")
      .map((c) => c.trim())
      .filter(Boolean);

    const categoryFilter =
      categories.length > 0
        ? `(${categories
            .map((c) => `itemCategoryCode eq '${c}'`)
            .join(" or ")})`
        : "";

    let filter = ["displayName ne ''", "blocked eq false", categoryFilter]
      .filter(Boolean)
      .join(" and ");

    if (search?.trim()) {
      const escapedSearch = search.replace(/'/g, "''");

      filter +=
        ` and (` +
        `contains(displayName,'${escapedSearch}') or ` +
        `contains(number,'${escapedSearch}')` +
        `)`;
    }

    const params: Record<string, string> = {
      $orderby: "displayName asc",
      $filter: filter,
    };

    const data = await bcGet<{ value: any[] }>("/items", params);

    return data.value.map(mapBCItem);
  } catch (error) {
    console.error("Failed to fetch items:", error);
    return [];
  }
}

// ======================================================
// GET ITEM BY NUMBER
// ======================================================

export async function getItemByNo(itemNo: string): Promise<BCItem | null> {
  try {
    const data = await bcGet<{
      value: any[];
    }>("/items", {
      $filter: `number eq '${itemNo}'`,
      $top: "1",
    });

    if (!data.value.length) {
      return null;
    }

    return mapBCItem(data.value[0]);
  } catch (error) {
    console.error(`Failed to fetch item ${itemNo}:`, error);

    return null;
  }
}

// ======================================================
// GET ITEM BY ID
// ======================================================

export async function getItemById(id: string): Promise<BCItem | null> {
  try {
    const data = await bcGet<any>(`/items(${id})`);

    return mapBCItem(data);
  } catch (error) {
    console.error(`Failed to fetch item ${id}:`, error);

    return null;
  }
}

// ======================================================
// GET ALL ITEMS
// ======================================================

export async function getAllItems(): Promise<BCItem[]> {
  try {
    const categories = (user?.ItemCat ?? "")
      .split("|")
      .map((c) => c.trim())
      .filter(Boolean);

    const categoryFilter =
      categories.length > 0
        ? `(${categories
            .map((c) => `itemCategoryCode eq '${c}'`)
            .join(" or ")})`
        : "";

    const filter = ["displayName ne ''", "blocked eq false", categoryFilter]
      .filter(Boolean)
      .join(" and ");

    const data = await bcGet<{ value: any[] }>("/items", {
      $orderby: "displayName asc",
      $filter: filter,
    });

    return data.value.map(mapBCItem);
  } catch (error) {
    console.error("Failed to fetch all items:", error);
    return [];
  }
}

// ======================================================
// BC ITEM MAPPER
// ======================================================

export function mapBCItem(bc: any): BCItem {
  return {
    id: bc.id,

    no: bc.number,

    description: bc.displayName || bc.displayName2 || "",

    unitPrice: Number(bc.unitPrice || bc.unitCost || 0),

    unitOfMeasureCode: bc.baseUnitOfMeasureCode || "PCS",

    inventory: Number(bc.inventory || 0),

    itemCategoryCode: bc.itemCategoryCode,

    type: bc.type,

    blocked: bc.blocked,
  };
}
