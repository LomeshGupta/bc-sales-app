"use client";

import React from "react";
import { useParams, useRouter } from "next/navigation";
import { Box, Button, Card, CardContent, Chip, CircularProgress, Divider, Grid, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Typography } from "@mui/material";
import { ArrowBack, ReceiptLong } from "@mui/icons-material";
import { useSalesInvoice, useSalesInvoiceLines } from "@/hooks/useQueries";
import { formatCurrency, formatDate } from "@/utils";
import { ROUTES } from "@/constants";

export default function SalesInvoiceDetailsPage() {
  const params = useParams<{ id: string }>();
  const router = useRouter();
  const id = params?.id || "";
  const { data: invoice, isLoading } = useSalesInvoice(id);
  const { data: lines = [], isLoading: linesLoading } = useSalesInvoiceLines(id);

  if (isLoading) return <Box sx={{ display: "flex", justifyContent: "center", py: 10 }}><CircularProgress /></Box>;
  if (!invoice) return <Box sx={{ p: { xs: 2, sm: 3 } }}><Button startIcon={<ArrowBack />} onClick={() => router.push(ROUTES.INVOICES)}>Back</Button><Typography sx={{ mt: 3 }}>Invoice not found</Typography></Box>;

  return (
    <Box sx={{ p: { xs: 2, sm: 3 }, maxWidth: 1400, mx: "auto", width: "100%" }}>
      <Button startIcon={<ArrowBack />} onClick={() => router.back()} sx={{ mb: 2 }}>Back</Button>

      <Card sx={{ mb: 3 }}>
        <CardContent>
          <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: 2, mb: 3 }}>
            <Box sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
              <ReceiptLong color="primary" />
              <Box>
                <Typography variant="h4" sx={{ fontWeight: 800 }}>{invoice.invoiceNo}</Typography>
                <Typography color="text.secondary">Posted on {formatDate(invoice.postingDate)}</Typography>
              </Box>
            </Box>
            <Chip label="Posted" color="success" variant="outlined" />
          </Box>
          <Divider sx={{ mb: 3 }} />
          <Grid container spacing={3}>
            <Grid size={{ xs: 12, md: 6 }}><Typography variant="subtitle2" gutterBottom>Customer No.</Typography><Typography>{invoice.customerNo || "-"}</Typography></Grid>
            <Grid size={{ xs: 12, md: 6 }}><Typography variant="subtitle2" gutterBottom>Customer Name</Typography><Typography>{invoice.customerName || "-"}</Typography></Grid>
            <Grid size={{ xs: 12, md: 6 }}><Typography variant="subtitle2" gutterBottom>Salesperson</Typography><Typography>{invoice.salesperson || "-"}</Typography></Grid>
            <Grid size={{ xs: 12, md: 6 }}><Typography variant="subtitle2" gutterBottom>Due Date</Typography><Typography>{invoice.dueDate ? formatDate(invoice.dueDate) : "-"}</Typography></Grid>
            <Grid size={{ xs: 12, md: 6 }}><Typography variant="subtitle2" gutterBottom>Location Code</Typography><Typography>{invoice.locationCode || "-"}</Typography></Grid>
            <Grid size={{ xs: 12, md: 6 }}><Typography variant="subtitle2" gutterBottom>Payment Terms</Typography><Typography>{invoice.paymentTermsCode || "-"}</Typography></Grid>
            <Grid size={12}><Typography variant="subtitle2" gutterBottom>Order No.</Typography><Typography>{invoice.orderNo || "-"}</Typography></Grid>
            <Grid size={12}><Typography variant="subtitle2" gutterBottom>External Document No.</Typography><Typography>{invoice.externalDocumentNo || "-"}</Typography></Grid>
            <Grid size={12}><Typography variant="subtitle2" gutterBottom>Invoice Total</Typography><Typography variant="h5" sx={{ fontWeight: 700, color: "primary.main" }}>{formatCurrency(invoice.amountIncludingVAT || invoice.amount, invoice.currency)}</Typography></Grid>
          </Grid>
        </CardContent>
      </Card>

      <Card>
        <CardContent>
          <Typography variant="h6" sx={{ fontWeight: 700, mb: 2 }}>Line Items</Typography>
          {linesLoading ? <Box sx={{ display: "flex", justifyContent: "center", py: 4 }}><CircularProgress /></Box> : lines.length === 0 ? <Typography color="text.secondary">No line items found</Typography> : (
            <TableContainer>
              <Table>
                <TableHead><TableRow>{["Line No", "Item No", "Description", "Qty", "Unit Price", "Discount %", "Total"].map((h) => <TableCell key={h} align={h === "Qty" || h === "Unit Price" || h === "Discount %" || h === "Total" ? "right" : "left"}>{h}</TableCell>)}</TableRow></TableHead>
                <TableBody>
                  {lines.map((line) => <TableRow key={line.id}>
                    <TableCell>{line.lineNo}</TableCell>
                    <TableCell>{line.itemNo}</TableCell>
                    <TableCell>{line.description}</TableCell>
                    <TableCell align="right">{line.quantity}</TableCell>
                    <TableCell align="right">{formatCurrency(line.unitPrice, invoice.currency)}</TableCell>
                    <TableCell align="right">{line.discountPercent || 0}%</TableCell>
                    <TableCell align="right">{formatCurrency(line.lineAmount, invoice.currency)}</TableCell>
                  </TableRow>)}
                </TableBody>
              </Table>
            </TableContainer>
          )}
        </CardContent>
      </Card>
    </Box>
  );
}
